# Wolf Down - Nível 3 (Castelo do Drácula) + boss final

## Como instalar
Extraia este zip **por cima da pasta do projeto** (a pasta onde está o `project.godot`), aceitando substituir:

- `autoload/game_manager.gd`  (substitui) - adiciona o nível 3 em `LEVELS` e `is_last_level()`
- `ui/level_complete.gd`      (substitui) - no último nível mostra "VICTORY" e o botão "BACK TO MENU"
- `leveis/level_3.tscn` e `leveis/level_3.gd` (novos) - a fase do chefe
- `boss_dracula/` (nova) - sprites, scripts e cenas do Drácula

Abra o projeto no Godot (ele importa os PNGs sozinho). Nenhum outro arquivo seu foi alterado.

## Fluxo
Nível 2 concluído -> CONTINUE -> Nível 3. O nível 3 não tem ondas nem temporizador: termina quando o Drácula morre
(2 s depois aparece a tela VICTORY com estatísticas). Antes do chefe o jogador recupera toda a vida.

## O Drácula
- Vida 280 (`max_health` no Inspector). Dano do jogador: bala = 1, faca = 1.
- Intro (~4 s invulnerável) -> 3 fases (100-66% / 66-33% / 33-0%).
- Ataques: leque de orbes, teleporte + tiro, poças de sangue (aviso de 1 s), invocação de morcegos (usa o morcego do jogo),
  investida em forma de morcego (fica vermelho antes de investir).
- Troca de fase: ruge, solta anel de orbes e invoca morcegos.
- Morte: se desfaz em cinzas, dá 5000 pontos e emite `defeated`.
- Integração: grupo `enemies`, camada 2 (balas já acertam), `update_health()` (faca), dano no jogador via `update_health()`.

## Ajustes rápidos
`boss_dracula/scripts/dracula_boss.gd`: vida, velocidade, velocidades/quantidades dos ataques (seção ATAQUES).
`leveis/level_3.gd`: `BOSS_AREA` (onde ele anda/teleporta) e limites de câmera.
Arena: `boss_dracula/sprites/arena_castle.png` (896x640), regenerável com `tools/generate_arena.py`;
sprites do Drácula com `tools/generate_sprites.py` (requer Pillow).
Colisões da arena ficam no nó `walls` do `level_3.tscn` (camada 4, como os tiles do jogo).
