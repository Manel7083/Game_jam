class_name ParticleFX
extends RefCounted
## Lightweight GPU particle bursts used for combat and progression feedback.
## Effects are one-shot, short-lived, use a tiny shared texture, and are capped
## so they cannot flood the scene during large enemy waves.

const MAX_ACTIVE_EFFECTS := 60
const TEXTURE_PATH := "res://effects/particle_dot.png"
static var _active_effects := 0
static var _texture: Texture2D

static func muzzle_flash(parent: Node, position: Vector2, direction: Vector2 = Vector2.RIGHT) -> void:
    # Small, tight muzzle flash: readable without filling the screen.
    _spawn_burst(parent, position, 4, 0.08, 55.0, 105.0, 0.8, 2.4, Color(1.0, 0.78, 0.35, 0.90), direction, 28.0)

static func hit_spark(parent: Node, position: Vector2) -> void:
    # Tiny impact spark so repeated hits remain lightweight.
    _spawn_burst(parent, position, 3, 0.10, 30.0, 70.0, 0.7, 1.9, Color(1.0, 0.92, 0.55, 0.85), Vector2.RIGHT, 160.0)

static func enemy_death(parent: Node, position: Vector2) -> void:
    _spawn_burst(parent, position, 12, 0.30, 25.0, 95.0, 2.0, 6.0, Color(0.62, 0.12, 0.18, 0.9), Vector2.RIGHT, 180.0)

static func player_damage(parent: Node, position: Vector2) -> void:
    # Subtle purple mist instead of a strong red burst. Fewer particles,
    # larger soft dots and very low velocity keep the effect atmospheric.
    _spawn_burst(parent, position, 5, 0.55, 6.0, 20.0, 2.8, 6.5, Color(0.55, 0.22, 0.85, 0.38), Vector2.UP, 360.0)

static func score_reward(parent: Node, position: Vector2) -> void:
    _spawn_burst(parent, position, 16, 0.45, 35.0, 95.0, 2.0, 5.0, Color(1.0, 0.83, 0.18, 0.9), Vector2.UP, 120.0)

static func objective_complete(parent: Node, position: Vector2) -> void:
    _spawn_burst(parent, position, 14, 0.50, 20.0, 70.0, 1.5, 4.0, Color(0.45, 1.0, 0.65, 0.85), Vector2.UP, 180.0)

static func pickup(parent: Node, position: Vector2) -> void:
    _spawn_burst(parent, position, 8, 0.35, 15.0, 45.0, 1.5, 3.0, Color(0.3, 0.9, 1.0, 0.85), Vector2.UP, 80.0)

static func attach_ambient_dust(parent: Node2D) -> void:
    if not is_instance_valid(parent) or parent.has_node("AmbientDust") or _texture == null and load(TEXTURE_PATH) == null:
        return
    if _texture == null:
        _texture = load(TEXTURE_PATH)
        if _texture == null:
            return

    var particles := GPUParticles2D.new()
    particles.name = "AmbientDust"
    particles.position = Vector2.ZERO
    particles.z_index = -1
    particles.texture = _texture
    particles.amount = 18
    particles.lifetime = 5.0
    particles.preprocess = 2.5
    particles.local_coords = true
    particles.randomness = 0.8
    particles.visibility_rect = Rect2(-220, -220, 440, 440)

    var material := ParticleProcessMaterial.new()
    material.direction = Vector3(0.0, -1.0, 0.0)
    material.spread = 180.0
    material.initial_velocity_min = 3.0
    material.initial_velocity_max = 9.0
    material.scale_min = 0.7
    material.scale_max = 1.6
    material.gravity = Vector3(0.0, -1.5, 0.0)
    material.damping_min = 1.0
    material.damping_max = 4.0

    var gradient := Gradient.new()
    gradient.colors = PackedColorArray([
        Color(0.75, 0.78, 0.9, 0.0),
        Color(0.75, 0.78, 0.9, 0.18),
        Color(0.75, 0.78, 0.9, 0.0)
    ])
    gradient.offsets = PackedFloat32Array([0.0, 0.35, 1.0])
    var ramp := GradientTexture1D.new()
    ramp.gradient = gradient
    material.color_ramp = ramp
    particles.process_material = material

    parent.add_child(particles)

static func _spawn_burst(
    parent: Node,
    position: Vector2,
    amount: int,
    lifetime: float,
    velocity_min: float,
    velocity_max: float,
    scale_min: float,
    scale_max: float,
    tint: Color,
    direction: Vector2,
    spread: float
) -> void:
    if not is_instance_valid(parent) or _active_effects >= MAX_ACTIVE_EFFECTS:
        return
    if _texture == null:
        _texture = load(TEXTURE_PATH)
        if _texture == null:
            return

    var particles := GPUParticles2D.new()
    particles.global_position = position
    particles.texture = _texture
    particles.amount = amount
    particles.lifetime = lifetime
    particles.one_shot = true
    particles.explosiveness = 1.0
    particles.randomness = 0.35
    particles.local_coords = false
    particles.z_index = 20
    particles.modulate = tint
    particles.visibility_rect = Rect2(-160, -160, 320, 320)

    var material := ParticleProcessMaterial.new()
    material.direction = Vector3(direction.normalized().x, direction.normalized().y, 0.0)
    material.spread = spread
    material.initial_velocity_min = velocity_min
    material.initial_velocity_max = velocity_max
    material.scale_min = scale_min
    material.scale_max = scale_max
    material.gravity = Vector3.ZERO
    material.damping_min = 20.0
    material.damping_max = 55.0

    var gradient := Gradient.new()
    gradient.colors = PackedColorArray([
        Color(1, 1, 1, 1),
        Color(1, 1, 1, 0)
    ])
    var ramp := GradientTexture1D.new()
    ramp.gradient = gradient
    material.color_ramp = ramp
    particles.process_material = material

    parent.add_child(particles)
    _active_effects += 1
    particles.finished.connect(_on_finished.bind(particles))
    particles.emitting = true

static func _on_finished(particles: GPUParticles2D) -> void:
    _active_effects = maxi(_active_effects - 1, 0)
    if is_instance_valid(particles):
        particles.queue_free()
