extends Control
## Experimental opening cinematic for Wolf Down.
## Lightweight: all scenery is drawn with CanvasItem primitives and Labels.

const SHOT_DURATION := [3.5, 5.5, 5.5, 5.5, 5.5, 6.5]
const TYPE_SPEED := 0.028

var _shot := 0
var _elapsed := 0.0
var _typing_index := 0
var _typing_time := 0.0
var _finished := false

var _story: Array[String] = [
	"For centuries, the village lived beneath a forgotten name.",
	"Then the graves opened. The dead returned, and the night\nlearned to hunt again.",
	"At the center of the curse stands an ancient castle.\nSomething inside has awakened.",
	"They call him Dracula.\nYou are the only one willing to enter the cursed land.",
	"You are Wolf.\nMove through the darkness. Find the source. Survive the night.",
	"CONTROLS\nWASD  Move        MOUSE  Aim\nLEFT CLICK  Shoot        R  Reload\nSPACE  Melee        Q  Interact\n\nThe hunt begins..."
]

var _labels: Array[Label] = []

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_build_ui()
	_reset_shot()
	queue_redraw()

func _process(delta: float) -> void:
	if _finished:
		return
	_elapsed += delta
	_typing_time += delta

	var text_value: String = _story[_shot]
	if _typing_index < text_value.length():
		var steps := int(_typing_time / TYPE_SPEED)
		if steps > 0:
			_typing_index = mini(_typing_index + steps, text_value.length())
			_typing_time = 0.0
			_story_label.text = text_value.substr(0, _typing_index)
	else:
		_story_label.text = text_value

	_progress_label.text = "%d / %d" % [_shot + 1, _story.size()]
	_fade_value = clampf(_elapsed / 0.7, 0.0, 1.0)
	queue_redraw()

	if _elapsed >= SHOT_DURATION[_shot]:
		_next_shot()

func _unhandled_input(event: InputEvent) -> void:
	if _finished:
		return
	if event.is_action_pressed("ui_accept") or event.is_action_pressed("pause"):
		_next_shot()
		get_viewport().set_input_as_handled()
	elif event is InputEventKey and event.pressed and not event.echo:
		_next_shot()
		get_viewport().set_input_as_handled()
	elif event is InputEventMouseButton and event.pressed:
		_next_shot()
		get_viewport().set_input_as_handled()

func _build_ui() -> void:
	_story_label = Label.new()
	_story_label.position = Vector2(72, 405)
	_story_label.size = Vector2(1136, 180)
	_story_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_story_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_story_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_story_label.add_theme_font_size_override("font_size", 30)
	_story_label.add_theme_color_override("font_color", Color(0.92, 0.88, 0.98, 1.0))
	_story_label.add_theme_color_override("font_shadow_color", Color(0.03, 0.01, 0.05, 0.95))
	_story_label.add_theme_constant_override("shadow_offset_x", 3)
	_story_label.add_theme_constant_override("shadow_offset_y", 3)
	add_child(_story_label)

	_title_label = Label.new()
	_title_label.position = Vector2(60, 65)
	_title_label.size = Vector2(1160, 95)
	_title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_title_label.add_theme_font_size_override("font_size", 46)
	_title_label.add_theme_color_override("font_color", Color(0.75, 0.56, 0.95, 0.96))
	add_child(_title_label)

	_progress_label = Label.new()
	_progress_label.position = Vector2(1050, 650)
	_progress_label.size = Vector2(160, 28)
	_progress_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_progress_label.add_theme_font_size_override("font_size", 16)
	_progress_label.add_theme_color_override("font_color", Color(0.65, 0.60, 0.70, 0.75))
	add_child(_progress_label)

	_hint_label = Label.new()
	_hint_label.position = Vector2(40, 650)
	_hint_label.size = Vector2(500, 28)
	_hint_label.add_theme_font_size_override("font_size", 16)
	_hint_label.add_theme_color_override("font_color", Color(0.68, 0.64, 0.74, 0.78))
	_hint_label.text = "ENTER / SPACE / CLICK — Continue    ESC — Skip"
	add_child(_hint_label)

func _reset_shot() -> void:
	_elapsed = 0.0
	_typing_time = 0.0
	_typing_index = 0
	_story_label.text = ""
	_title_label.text = _titles[_shot]
	_title_label.visible = _shot != 5
	_hint_label.visible = true
	queue_redraw()

func _next_shot() -> void:
	if _typing_index < _story[_shot].length():
		_typing_index = _story[_shot].length()
		_story_label.text = _story[_shot]
		return

	if _shot >= _story.size() - 1:
		_finish()
		return

	_shot += 1
	_reset_shot()

func _finish() -> void:
	if _finished:
		return
	_finished = true
	_hint_label.visible = false
	_progress_label.visible = false
	await get_tree().create_timer(0.6, true, false, true).timeout
	if is_instance_valid(GameManager):
		GameManager.load_level(1)

func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
		_finish()
		get_viewport().set_input_as_handled()

var _story_label: Label
var _title_label: Label
var _hint_label: Label
var _progress_label: Label
var _fade_value := 0.0

var _titles: Array[String] = [
	"WOLF DOWN — PROLOGUE",
	"THE GRAVES REMEMBER",
	"THE CASTLE AWAKENS",
	"THE NAME IN THE DARK",
	"THE HUNTER",
	"HOW TO SURVIVE"
]

func _draw() -> void:
	var size := get_viewport_rect().size
	# Deep background.
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.025, 0.018, 0.045, 1.0))

	# Shot-specific imagery, deliberately abstract and cheap to render.
	match _shot:
		0:
			_draw_moon_scene(size, false)
		1:
			_draw_graves_scene(size)
		2:
			_draw_castle_scene(size)
		3:
			_draw_castle_scene(size, true)
		4:
			_draw_hunter_scene(size)
		5:
			_draw_controls_scene(size)

	# Cinematic letterbox.
	var bar_h := 72.0
	draw_rect(Rect2(0, 0, size.x, bar_h), Color(0.0, 0.0, 0.0, 0.94))
	draw_rect(Rect2(0, size.y - bar_h, size.x, bar_h), Color(0.0, 0.0, 0.0, 0.94))

	# Soft vignette strips.
	draw_rect(Rect2(0, bar_h, 42, size.y - bar_h * 2.0), Color(0.0, 0.0, 0.0, 0.18))
	draw_rect(Rect2(size.x - 42, bar_h, 42, size.y - bar_h * 2.0), Color(0.0, 0.0, 0.0, 0.18))

func _draw_moon_scene(size: Vector2, red_moon := false) -> void:
	draw_circle(Vector2(size.x * 0.78, 190), 85, Color(0.58, 0.50, 0.72, 0.18))
	draw_circle(Vector2(size.x * 0.78, 190), 62, Color(0.78, 0.77, 0.90, 0.90) if not red_moon else Color(0.72, 0.25, 0.35, 0.90))
	for i in range(6):
		var x := 110.0 + i * 190.0
		var y := 320.0 + sin(float(i) * 1.7) * 20.0
		draw_colored_polygon(PackedVector2Array([
			Vector2(x, 500), Vector2(x + 36, y), Vector2(x + 74, 500)
		]), Color(0.06, 0.055, 0.10, 1.0))
	_draw_ground(size)

func _draw_graves_scene(size: Vector2) -> void:
	_draw_moon_scene(size)
	for i in range(11):
		var x := 72.0 + i * 108.0
		var h := 52.0 + float((i * 17) % 33)
		draw_rect(Rect2(x, 505 - h, 58, h), Color(0.12, 0.12, 0.17, 1.0))
		draw_arc(Vector2(x + 29, 505 - h), 29, PI, TAU, 16, Color(0.12, 0.12, 0.17, 1.0), 20)
		if i % 3 == 0:
			draw_line(Vector2(x + 29, 495 - h), Vector2(x + 29, 445 - h), Color(0.40, 0.32, 0.50, 0.65), 4)
			draw_line(Vector2(x + 12, 462 - h), Vector2(x + 46, 462 - h), Color(0.40, 0.32, 0.50, 0.65), 4)

func _draw_castle_scene(size: Vector2, awakened := false) -> void:
	var sky := Color(0.055, 0.03, 0.09, 1.0) if not awakened else Color(0.11, 0.025, 0.065, 1.0)
	draw_rect(Rect2(0, 72, size.x, size.y - 144), sky)
	draw_circle(Vector2(870, 180), 72, Color(0.78, 0.77, 0.90, 0.80) if not awakened else Color(0.78, 0.24, 0.32, 0.9))
	# Castle silhouette.
	var base := Rect2(420, 250, 380, 270)
	draw_rect(base, Color(0.04, 0.035, 0.065, 1.0))
	for x in [420.0, 700.0]:
		draw_rect(Rect2(x, 185, 90, 335), Color(0.035, 0.03, 0.055, 1.0))
		draw_colored_polygon(PackedVector2Array([
			Vector2(x - 5, 185), Vector2(x + 45, 125), Vector2(x + 95, 185)
		]), Color(0.035, 0.03, 0.055, 1.0))
	for wx in [455.0, 585.0, 735.0]:
		draw_circle(Vector2(wx, 325), 13, Color(0.42, 0.18, 0.56, 0.75) if not awakened else Color(0.86, 0.18, 0.24, 0.8))
	_draw_ground(size)

func _draw_hunter_scene(size: Vector2) -> void:
	_draw_moon_scene(size)
	# Stylized Wolf silhouette.
	var c := Vector2(size.x * 0.48, 365)
	draw_circle(c, 42, Color(0.05, 0.035, 0.075, 1.0))
	draw_rect(Rect2(c.x - 24, c.y + 28, 48, 120), Color(0.05, 0.035, 0.075, 1.0))
	draw_line(c + Vector2(-14, 145), c + Vector2(-34, 225), Color(0.05, 0.035, 0.075, 1.0), 17)
	draw_line(c + Vector2(14, 145), c + Vector2(34, 225), Color(0.05, 0.035, 0.075, 1.0), 17)
	draw_line(c + Vector2(-16, 62), c + Vector2(-88, 105), Color(0.05, 0.035, 0.075, 1.0), 13)
	# Weapon line.
	draw_line(c + Vector2(-88, 105), c + Vector2(-142, 92), Color(0.35, 0.20, 0.42, 0.9), 7)
	# Eye glint.
	draw_circle(c + Vector2(-10, -8), 4, Color(0.75, 0.48, 0.92, 0.95))

func _draw_controls_scene(size: Vector2) -> void:
	_draw_ground(size)
	# Minimal control cards.
	var cards := [
		[Vector2(270, 205), Vector2(300, 120)],
		[Vector2(630, 205), Vector2(300, 120)],
		[Vector2(270, 365), Vector2(660, 150)]
	]
	for card in cards:
		draw_style_box(_make_box(Color(0.08, 0.055, 0.12, 0.92), Color(0.35, 0.22, 0.46, 0.65)), Rect2(card[0], card[1]))

func _draw_ground(size: Vector2) -> void:
	draw_rect(Rect2(0, 500, size.x, size.y - 572), Color(0.035, 0.04, 0.055, 1.0))
	for i in range(14):
		var x := float(i * 110 + 20)
		draw_line(Vector2(x, 500), Vector2(x + 40, 620), Color(0.09, 0.08, 0.12, 0.55), 2)

func _make_box(fill: Color, border: Color) -> StyleBoxFlat:
	var box := StyleBoxFlat.new()
	box.bg_color = fill
	box.border_color = border
	box.set_border_width_all(1)
	box.corner_radius_top_left = 8
	box.corner_radius_top_right = 8
	box.corner_radius_bottom_left = 8
	box.corner_radius_bottom_right = 8
	return box
